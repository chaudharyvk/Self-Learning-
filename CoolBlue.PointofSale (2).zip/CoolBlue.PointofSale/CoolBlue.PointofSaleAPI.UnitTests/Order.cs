﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CoolBlue.PointofSaleAPI.UnitTests
{
    [TestClass]
    public class Order
    {
        [TestMethod]
        public void AddProductToAnOrder()
        {

        }

        [TestMethod]
        public void AddProductBundleToAnOrder()
        {

        }


        [TestMethod]
        public void AddMutilpleProductToAnOrder()
        {

        }
    }
}
