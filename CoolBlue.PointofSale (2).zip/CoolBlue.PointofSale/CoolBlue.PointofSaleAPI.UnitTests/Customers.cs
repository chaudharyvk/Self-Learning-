﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoolBlue.PointofSaleAPI.UnitTests
{
    [TestClass]
    public class Customers
    {

        [TestMethod]
        public void AddCustomer()
        {

        }

        [TestMethod]
        public void SearchForRegularCustomer()
        {

        }

    }
}
