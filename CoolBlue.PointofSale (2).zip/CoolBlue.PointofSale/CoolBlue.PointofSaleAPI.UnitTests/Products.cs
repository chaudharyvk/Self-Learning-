﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CoolBlue.PointofSaleAPI.UnitTests
{
    [TestClass]
    public class Products
    {
        [TestMethod]
        public void GetAllProducts()

        {
        }

        [TestMethod]
        public void SearchProduct()
        {

        }

        [TestMethod]
        public void SearchProductBundles()
        {

        }

       
       
    }
}
